library(shiny)
library(shinyjs)
library(openxlsx)
library(plotly)
library(lubridate)
library(tidyr)
library(plotly)
library(dplyr)
library(RColorBrewer)
library(zip)
library(gdfilter)

name_file <- "empty_sagic_template"
ext <- ".xlsx"
file_path <- system.file("examples", paste0(name_file, ext), package = "gdfilter")

ui <- fluidPage(

  div(class = "mainbody",
      useShinyjs(),
      tags$head(tags$link(rel = "stylesheet", href = "style2.css", type = "text/css")),

      div(class = "titulo_tema",
          h1("GDfilter", HTML("<sub class=\"versao-label\">v 0.0.1</sub>")),
          "Simplificando o tratamento de dados de MMGD."
          ),

      div(class = "inputbox",
          div(class = "all_inputs",
              div(class = "listelements",
                  div(class = "texto",
                    downloadLink("downloadTemplate", "(Download Template aqui)"),
                  ),
                  fileInput("file",buttonLabel = "Search...",placeholder = "Select files",label = "",
                            accept = c(".xlsx", ".xls")),

              )
          ),
          div(class = "outputs",
              div(class = "listelements",
                  downloadButton("downloadData", class = "baixar-pdf-btn", "Download Dados Processados"),
              )
          )
      ),



      div(class = "grafico",
          div(class = "graphfilters",
              selectInput("mes", "", width = "200px", choices = NULL),
              selectInput("tipo_curva", "", width = "200px",
                          choices = list("Carga Global" = "Carga Global",
                                         "MMGD" = "MMGD"),
                          selected = "Carga Global")
          ),
          div(class = "plotly-group",
              column(width = 6,
                     plotlyOutput("distPlot")
              ),
              column(width = 6,
                     div(class = "plot-container",
                         plotlyOutput("distPlot_treated"),
                         div(id = "cover", class = "cover-div",
                             div(class = "custom-spinner",
                                 "GDfilter está fazendo Mágica!",
                                 HTML('<svg viewBox="0 0 240 100" preserveAspectRatio="none">
                              <path d="
                                M0 20
                                L10 25
                                L20 27
                                L30 30
                                L40 35
                                L50 39
                                L60 45
                                L70 40
                                L80 28
                                L90 24
                                L100 20
                                L110 18
                                L120 20
                                L130 18
                                L140 15
                                L150 14
                                L160 15
                                L170 18
                                L180 24
                                L190 30
                                L200 27
                                L210 24
                                L220 24
                                L230 20
                                L240 15
                                " />
                              <path d="
                                M0 20
                                L10 25
                                L20 27
                                L30 30
                                L40 35
                                L50 39
                                L60 45
                                L70 40
                                L80 28
                                L90 24
                                L100 20
                                L110 18
                                L120 20
                                L130 18
                                L140 15
                                L150 14
                                L160 15
                                L170 18
                                L180 24
                                L190 30
                                L200 27
                                L210 24
                                L220 24
                                L230 20
                                L240 15
                                " />
                          </svg>')
                             )
                         )
                     )
              )
          )
      ),

      tags$script(HTML("
        $(document).ready(function() {
          var downloadIcon = $('#downloadData i');
          if (downloadIcon.length) {
            downloadIcon.attr('id', 'download-icon');
          }
        });
      "))

  )
)

server <- function(input, output, session) {
  shinyjs::disable("downloadData")

  meses_portugues <- c("JAN", "FEV", "MAR", "ABR", "MAI", "JUN", "JUL", "AGO", "SET", "OUT", "NOV", "DEZ")

  data_ <- reactive({
    req(input$file)
    data_template_sagic <- read.xlsx(input$file$datapath, sheet = 1, startRow = 2)
    data_treated <- treat_data_template_sagic(data_template_sagic)
    data_treated
  })

  data_transformed <- reactive({
    req(data_())
    result <- load_prettysignal(data_(), TRUE, FALSE, 2)
    result

  })

  data_new_sagic <- reactive({
    req(data_())
    req(data_transformed())

    data_original <- data_()
    data_transformed <- data_transformed()

    # Substituindo a coluna microminigersolar
    data_original$microminigersolar <- data_transformed$Filtered_microminigersolar

    data_original
  })

  filtered_data <- reactive({
    req(data_())
    req(input$mes)
    data_() %>% filter(month_year == input$mes)
  })

  processed_data <- reactive({
    req(data_transformed())
    req(input$mes)

    mes_ano <- strsplit(input$mes, "-")[[1]]
    month_name <- toupper(mes_ano[1])
    month <- which(meses_portugues == month_name)
    year <- as.numeric(mes_ano[2])
    data_transformed() %>% filter(month_ == month, year_ == year)
  })

  observeEvent(input$file, {
    req(data_())
    initial_month <- unique(data_()$month_year)[1]
    updateSelectInput(session, "mes",
                      choices = unique(data_()$month_year),
                      selected = initial_month)
  })

  initial_data <- data.frame(
    Time = seq(from = as.POSIXct("2023-01-01 01:00"), by = "hour", length.out = 24),
    Value = rep(1, 24)
  )

  output$distPlot <- renderPlotly({
    plot_ly(data = initial_data, x = ~Time, y = ~Value, type = 'scatter', mode = 'lines', line = list(color = 'rgba(0,0,0,0.01)')) %>%
      layout(
        title = "Curvas Originais",
        xaxis = list(title = "Time"),
        yaxis = list(title = "Data"),
        showlegend = FALSE
      )
  })

  output$distPlot_treated <- renderPlotly({
    plot_ly(data = initial_data, x = ~Time, y = ~Value, type = 'scatter', mode = 'lines', line = list(color = 'rgba(0,0,0,0.01)')) %>%
      layout(
        title = "Curvas Tratadas",
        xaxis = list(title = "Time"),
        yaxis = list(title = "Data"),
        showlegend = FALSE
      )
  })

  observeEvent(filtered_data(), {
    req(filtered_data())
    df_o <- filtered_data()
    updatePlots(df_o, processed_data())
  })

  observeEvent(processed_data(), {
    req(processed_data())
    df <- processed_data()
    updatePlots(filtered_data(), df)
    shinyjs::enable("downloadData")
  })

  observeEvent(input$tipo_curva, {
    req(filtered_data(), processed_data(), input$tipo_curva)
    df_o <- filtered_data()
    df <- processed_data()
    updatePlots(df_o, df)
  })

  updatePlots <- function(df_o, df) {

    runjs("document.getElementById('cover').style.transition = 'none';")
    runjs("document.getElementById('cover').style.left = '0%';")

    if (input$tipo_curva == "Carga Global") {
      values_1 <- as.numeric(df_o$globalload)
      values_2 <- as.numeric(df$Filtered_microminigersolar + df$Original_liquidofmmgdload)
    } else if (input$tipo_curva == "MMGD") {
      values_1 <- as.numeric(df_o$microminigersolar)
      values_2 <- as.numeric(df$microminigersolar_Ajusted)
    }

    y_min <- min(c(values_1, values_2))
    y_max <- max(c(values_1, values_2))
    y_range <- c(0.8 * y_min, 1.15 * y_max)

    output$distPlot <- renderPlotly({
      df_hour = format(df_o$time, "%H")
      df_hour_numeric <- as.numeric(df_hour) + 1
      fig <- gera_graficos_muitas_series(df_o, df_hour_numeric, values_1, as.factor(format(df_o$time, "%d/%m")))
      fig <- fig %>% layout(
        title = "Curvas Originais",
        yaxis = list(range = y_range, title = "Data"),
        xaxis = list(title = "Hora", dtick = 1, tickvals = 1:24)
      )
      fig
    })
    
    output$distPlot_treated <- renderPlotly({
      df_hour = format(df$time, "%H")
      df_hour_numeric <- as.numeric(df_hour) + 1
      fig1 <- gera_graficos_muitas_series(df, df_hour_numeric, values_2, as.factor(format(df$time, "%d/%m")))
      fig1 <- fig1 %>% layout(
        title = "Curvas Tratadas",
        yaxis = list(range = y_range, title = "Data"),
        xaxis = list(title = "Hora", dtick = 1, tickvals = 1:24)
      )
      fig1
    })

    # Add a small delay before starting the transition
    runjs("
      setTimeout(function() {
        document.getElementById('cover').style.transition = 'left 1.5s';
        document.getElementById('cover').style.left = '100%';
      }, 2000);
    ")
  }

  output$downloadData <- downloadHandler(


    filename = function() {
      paste0("loadprettysignal_results_", Sys.Date(),".zip")
    },
    content = function(file) {
      runjs("$('#download-icon').addClass('rotating');")
      tmpdir <- tempdir()
      setwd(tempdir())

      # Chamando a função para processar e salvar os dados
      fs_ <- download_sagic_treated_lps(data_new_sagic(), tmpdir, file_path)

      # Compactando os arquivos em um único arquivo zip
      zip(zipfile=file, files = fs_)

      runjs("$('#download-icon').removeClass('rotating');")
    }, contentType = "application/zip"
  )

  output$downloadTemplate <- downloadHandler(
    filename = function() {
      paste0("template_sagic_to_fill", ".xlsx")
    },
    content = function(file) {
      file.copy(file_path, file)
    }
  )
}

shinyApp(ui = ui, server = server)

