
#' GDfilter
#'
#' Essa função abrirá em seu navegador um aplicativo para tratamento em lote de dados de MMGD.
#' @export
run_gdfilter <- function() {

  library(shiny)

  file_path <- system.file("examples",
                           paste0("gdfilter.R"),
                           package = "gdfilter")
  runApp(file_path)
}

#' @export
treat_data_template_sagic <- function(df_sagic){

  colnames_ <- c(
    "timesagic",
    "gerhidropropria",
    "gertermpropria",
    "gereolicapropria",
    "gersolarpropria",
    "gerhidroterceiro",
    "gertermterceiro",
    "gereolicaterceiro",
    "gersolarterceiro",
    "microminigerhidro",
    "microminigerterm",
    "microminigereolica",
    "microminigersolar",
    "intergerhidro",
    "intgertermo",
    "intgereolica",
    "intgersolar",
    "intredebaisica",
    "intoutrodistrib",
    "intinternac",
    "intditc",
    "globalload"
  )
  colnames(df_sagic) <- colnames_
  df_sagic <- df_sagic[!grepl("^M", df_sagic$timesagic), ]

  df_sagic <- df_sagic %>%
    mutate(
      year_ = as.integer(substring(timesagic, 7, 10)),
      month_ = as.integer(substring(timesagic, 4, 5)),
      day_ = as.integer(substring(timesagic, 1, 2)),
      hour_ = as.integer(substring(timesagic, 12, 13)) - 1
    )

  df_sagic <- df_sagic %>%
    mutate(
      time = make_datetime(year_, month_, day_, hour_),
      month_year = toupper(format(time, "%b-%Y"))
    )

  df_sagic <- df_sagic %>%
    select(timesagic, time, year_, month_, day_, hour_, month_year, everything())

  df_sagic[is.na(df_sagic)] <- 0
  df_sagic[, 8:27] <- lapply(df_sagic[, 8:27], as.numeric)
  df_sagic <- df_sagic %>%
    mutate(
      gertotal = rowSums(.[, 8:19]),
      intertotal = rowSums(.[, 20:27])
    )
  df_sagic$globalload <- df_sagic$gertotal - df_sagic$intertotal
  df_sagic$liquidofmmgdload = df_sagic$globalload - df_sagic$microminigersolar

  return(data.frame(
    time = df_sagic$time,
    year_ = df_sagic$year_,
    month_ = df_sagic$month_,
    day_ = df_sagic$day_,
    hour_ = df_sagic$hour_,
    month_year = df_sagic$month_year,
    globalload = df_sagic$globalload,
    liquidofmmgdload = df_sagic$liquidofmmgdload,
    gerhidropropria = df_sagic$gerhidropropria,
    gertermpropria = df_sagic$gertermpropria,
    gereolicapropria = df_sagic$gereolicapropria,
    gersolarpropria = df_sagic$gersolarpropria,
    gerhidroterceiro = df_sagic$gerhidroterceiro,
    gertermterceiro = df_sagic$gertermterceiro,
    gereolicaterceiro = df_sagic$gereolicaterceiro,
    gersolarterceiro = df_sagic$gersolarterceiro,
    microminigerhidro = df_sagic$microminigerhidro,
    microminigerterm = df_sagic$microminigerterm,
    microminigereolica = df_sagic$microminigereolica,
    microminigersolar = df_sagic$microminigersolar,
    intergerhidro = df_sagic$intergerhidro,
    intgertermo = df_sagic$intgertermo,
    intgereolica = df_sagic$intgereolica,
    intgersolar = df_sagic$intgersolar,
    intredebaisica = df_sagic$intredebaisica,
    intoutrodistrib = df_sagic$intoutrodistrib,
    intinternac = df_sagic$intinternac,
    intditc = df_sagic$intditc
  ))


}

download_sagic_treated <- function(agente_info, results, dir_template) {

  results$Hour <- rep(1:24, length.out = nrow(results))
  results <- results %>%
    mutate(Time_Sagic = as.character(paste(sprintf("%02d", day_), "/", sprintf("%02d", month_), "/", year_, " ", sprintf("%02d", hour_+1), sep = "")))

  # Separando os dados por mês e ano
  results_grouped <- results %>%
    group_by(year_, month_) %>%
    group_split()

  for (data_chunk in results_grouped) {
    print(data_chunk)
    # Extraindo informações de ano e mês
    year <- unique(data_chunk$year_)
    month <- unique(data_chunk$month_)

    # Criando o nome do arquivo
    month_name <- toupper(format(as.Date(paste0(year, "-", month, "-01")), "%b"))

    file_name <- sprintf("%02d - %s - %s.xlsx",
                         month, results$month_year, Sys.Date())

    # Criando um novo workbook e adicionando uma planilha
    wb <- loadWorkbook(paste0(dir_template,"template_sagic.xlsx"))
    addWorksheet(wb, "sheet1")

    # Escrevendo Time_Sagic na coluna A a partir da linha 3
    writeData(wb, sheet = 1, data_chunk$Time_Sagic, startCol = 1, startRow = 3, colNames = FALSE)

    # Escrevendo Micro_Mini_Ger_Solar na coluna M a partir da linha 3
    writeData(wb, sheet = 1, data_chunk$microminigersolar_Ajusted, startCol = 13, startRow = 3, colNames = FALSE)

    # Escrevendo Int_Rede_Basica na coluna R a partir da linha 3
    writeData(wb, sheet = 1, -1 * data_chunk$Original_liquidofmmgdload, startCol = 18, startRow = 3, colNames = FALSE)

    # Salvando o arquivo Excel
    saveWorkbook(wb, paste0(dir_template,file_name), overwrite = TRUE)
  }
}

#' @export
download_sagic_treated_lps <- function(results, save_dir, dir_template) {

  results$Hour <- rep(1:24, length.out = nrow(results))
  results <- results %>%
    mutate(Time_Sagic = as.character(paste(sprintf("%02d", day_), "/", sprintf("%02d", month_), "/", year_, " ", sprintf("%02d", hour_+1), sep = "")))

  # Separando os dados por mês e ano
  results_grouped <- results %>%
    group_by(year_, month_) %>%
    group_split()

  fs <- c()

  for (data_chunk in results_grouped) {
    year <- unique(data_chunk$year_)
    month <- unique(data_chunk$month_)

    # Criando o nome do arquivo
    month_name <- toupper(format(as.Date(paste0(year, "-", month, "-01")), "%b"))
    # Garantindo que o nome do arquivo não tenha caracteres inválidos
    file_name <- paste0(month_name, Sys.Date(), ".xlsx")
    fs <- c(fs, file_name)

    # Criando um novo workbook e adicionando uma planilha
    wb <- loadWorkbook(dir_template)
    addWorksheet(wb, "sheet1")

    # Escrevendo os dados no arquivo Excel
    writeData(wb, sheet = 1, data_chunk$Time_Sagic, startCol = 1, startRow = 3, colNames = FALSE)
    writeData(wb, sheet = 1, data_chunk$gerhidropropria, startCol = 2, startRow = 3, colNames = FALSE)
    writeData(wb, sheet = 1, data_chunk$gertermpropria, startCol = 3, startRow = 3, colNames = FALSE)
    writeData(wb, sheet = 1, data_chunk$gereolicapropria, startCol = 4, startRow = 3, colNames = FALSE)
    writeData(wb, sheet = 1, data_chunk$gersolarpropria, startCol = 5, startRow = 3, colNames = FALSE)
    writeData(wb, sheet = 1, data_chunk$gerhidroterceiro, startCol = 6, startRow = 3, colNames = FALSE)
    writeData(wb, sheet = 1, data_chunk$gertermterceiro, startCol = 7, startRow = 3, colNames = FALSE)
    writeData(wb, sheet = 1, data_chunk$gereolicaterceiro, startCol = 8, startRow = 3, colNames = FALSE)
    writeData(wb, sheet = 1, data_chunk$gersolarterceiro, startCol = 9, startRow = 3, colNames = FALSE)
    writeData(wb, sheet = 1, data_chunk$microminigerhidro, startCol = 10, startRow = 3, colNames = FALSE)
    writeData(wb, sheet = 1, data_chunk$microminigerterm, startCol = 11, startRow = 3, colNames = FALSE)
    writeData(wb, sheet = 1, data_chunk$microminigereolica, startCol = 12, startRow = 3, colNames = FALSE)
    writeData(wb, sheet = 1, data_chunk$microminigersolar, startCol = 13, startRow = 3, colNames = FALSE)
    writeData(wb, sheet = 1, data_chunk$intergerhidro, startCol = 14, startRow = 3, colNames = FALSE)
    writeData(wb, sheet = 1, data_chunk$intgertermo, startCol = 15, startRow = 3, colNames = FALSE)
    writeData(wb, sheet = 1, data_chunk$intgereolica, startCol = 16, startRow = 3, colNames = FALSE)
    writeData(wb, sheet = 1, data_chunk$intgersolar, startCol = 17, startRow = 3, colNames = FALSE)
    writeData(wb, sheet = 1, data_chunk$intredebaisica, startCol = 18, startRow = 3, colNames = FALSE)
    writeData(wb, sheet = 1, data_chunk$intoutrodistrib, startCol = 19, startRow = 3, colNames = FALSE)
    writeData(wb, sheet = 1, data_chunk$intinternac, startCol = 20, startRow = 3, colNames = FALSE)
    writeData(wb, sheet = 1, data_chunk$intditc, startCol = 21, startRow = 3, colNames = FALSE)

    # Salvando o arquivo Excel no diretório temporário
    saveWorkbook(wb, file.path(save_dir, file_name), overwrite = TRUE)
  }

  return(fs)
}

#' @export
load_prettysignal <- function(data_to_be_treated, midnight_is_first_hour, peakadjustement, metodo) {
  #para testar a fun
  # data_to_be_treated <- dados_sagic
  # metodo <- 2
  # midnight_is_first_hour <- TRUE
  # peakadjustement <- FALSE
  # Transformar a coluna microminigersolar em numeric
  data_to_be_treated <- data_to_be_treated %>%
    mutate(microminigersolar = as.numeric(microminigersolar),
           liquidofmmgdload = as.numeric(liquidofmmgdload))

  # Ordenar os dados por Year, month_, Day, Hour
  data_to_be_treated <- data_to_be_treated %>%
    arrange(year_, month_, day_, hour_)

  # Verificação de mês dentro do domínio de 1 a 12
  if (any(data_to_be_treated$month_ < 1 | data_to_be_treated$month_ > 12)) {
    stop("Erro: Os meses devem estar no domínio de 1 a 12.Revise seus dados, há um ou mais número de meses fora desse intervalo.")
  }

  # Verificação de dias dentro do domínio de 1 a 31
  if (any(data_to_be_treated$day_ < 1 | data_to_be_treated$day_ > 31)) {
    stop("Erro: Os dias devem estar no domínio de 1 a 31. Revise seus dados, há um ou mais número de dias fora desse intervalo.")
  }

  # Verificação de horas dentro do domínio de 0 a 23
  if (any(data_to_be_treated$hour_ < 0 | data_to_be_treated$hour_ > 23)) {
    stop("Erro: As horas devem estar do domínio de 1 a 24. Revise seus dados, há uma ou mais horários fora desse intervalo.")
  }

  # Verificação de dias em fevereiro
  invalid_february_days <- data_to_be_treated %>%
    filter(month_ == 2 & ((day_ > 29) | (day_ == 29 & !leap_year(year_)))) %>%
    select(year_, month_, day_)

  if (nrow(invalid_february_days) > 0) {
    stop("Erro: Existem dias inválidos no mês de fevereiro.")
  }

  # Função para tratar cada dia individualmente
  tratar_dia <- function(dado_de_um_dia, year, month, day) {
    # Verificação de hora repetida dentro de um dia
    if (any(duplicated(dado_de_um_dia$hour_))) {
      stop(paste("Erro: Existem horas repetidas no dia", day, "do mês", month, "do ano", year, "."))
    }

    if (nrow(dado_de_um_dia) != 24) {
      stop(paste("Erro: O dia", day, "do mês", month, "do ano", year, "não possui 24 valores."))
    }

    dados_de_um_dia_mmgd_store <- dado_de_um_dia$microminigersolar
    dados_de_um_dia_liquid <- dado_de_um_dia$liquidofmmgdload
    #corrigido_signal <- corrigir_dentes(dado_de_um_dia$Data)
    dados_de_um_dia_mmgd <- dado_de_um_dia$microminigersolar

    # Aplicando a Transformada de Fourier
    fft_dados_de_um_dia_mmgd <- fft(dados_de_um_dia_mmgd)
    n_dia <- length(dados_de_um_dia_mmgd)
    frequencias_dia <- seq(0, n_dia-1) / n_dia * (1/1)  # Ciclos por hora
    limite_frequencia_dia <- 0.20

    # Filtrando as altas frequências
    fft_dados_de_um_dia_mmgd[4] <- 0.2*fft_dados_de_um_dia_mmgd[4]
    fft_dados_de_um_dia_mmgd[length(fft_dados_de_um_dia_mmgd)-2] <- 0.2*fft_dados_de_um_dia_mmgd[4]
    fft_dados_de_um_dia_mmgd[frequencias_dia > limite_frequencia_dia & frequencias_dia < 1 - limite_frequencia_dia] <- 0

    # Aplicando a Transformada de Fourier Inversa
    dados_de_um_dia_mmgd_filtrado <- Re(fft(fft_dados_de_um_dia_mmgd, inverse = TRUE) / n_dia)
    dados_de_um_dia_mmgd_filtrado <- dados_de_um_dia_mmgd_filtrado - min(dados_de_um_dia_mmgd_filtrado)


    # Identificando intervalos de Zeros
    rle_zeros <- rle(dados_de_um_dia_mmgd == 0)
    starts_ends <- data.frame(
      Start = cumsum(rle_zeros$lengths)[rle_zeros$values] - rle_zeros$lengths[rle_zeros$values] + 1,
      End = cumsum(rle_zeros$lengths)[rle_zeros$values],
      Length = rle_zeros$lengths[rle_zeros$values]
    )

    # Filtrando e calculando o valor médio dos intervalos de zero no vetor filtrado
    valores_medios <- sapply(1:nrow(starts_ends), function(i) {
      mean(dados_de_um_dia_mmgd_filtrado[starts_ends$Start[i]:starts_ends$End[i]])
    })

    maior_valor_medio <- max(valores_medios)
    dados_de_um_dia_mmgd_filtrado <- dados_de_um_dia_mmgd_filtrado - maior_valor_medio
    for(i in 1:nrow(starts_ends)) {
      dados_de_um_dia_mmgd_filtrado[starts_ends$Start[i]:starts_ends$End[i]] <- 0
    }
    dados_de_um_dia_mmgd_filtrado[dados_de_um_dia_mmgd_filtrado < 0] <- 0

    # Identificar os valores que não são zero
    non_zero_values <- which(dados_de_um_dia_mmgd != 0)

    # Replicar os dois primeiros valores diferentes de zero
    if (length(non_zero_values) > 0) {
      first_non_zero_values <- non_zero_values[1:2]
      dados_de_um_dia_mmgd_filtrado[first_non_zero_values] <- dados_de_um_dia_mmgd[first_non_zero_values]
    }

    # Replicar os dois últimos valores diferentes de zero
    if (length(non_zero_values) > 0) {
      last_non_zero_values <- non_zero_values[(length(non_zero_values)-1):length(non_zero_values)]
      dados_de_um_dia_mmgd_filtrado[last_non_zero_values] <- dados_de_um_dia_mmgd[last_non_zero_values]
    }


    #------- Calculando a FFT do sinal liquido --------------------------------
    fft_dados_de_um_dia <- fft(dados_de_um_dia_liquid)
    n_dia <- length(dados_de_um_dia_liquid)
    magnitudes <- Mod(dados_de_um_dia_liquid)
    frequencias_dia <- seq(0, n_dia-1) / n_dia * (1/1)
    limite_frequencia_dia <- 0.17
    taxa_amostragem <- 1
    frequencias_hz <- (0:(n_dia-1)) * taxa_amostragem / n_dia
    # Filtrando as altas frequências
    #fft_dados_de_um_dia[frequencias_dia > limite_frequencia_dia & frequencias_dia < 1 - limite_frequencia_dia] <- 0
    fft_dados_de_um_dia[(frequencias_dia > 0.2 & frequencias_dia < 0.4) | (frequencias_dia < 0.8 & frequencias_dia > 0.6)] <- 
      fft_dados_de_um_dia[(frequencias_dia > 0.2 & frequencias_dia < 0.4) | (frequencias_dia < 0.8 & frequencias_dia > 0.6)] * 0.3
    
    # Multiplicar por 0.2 no intervalo de 0.4 a 0.8
    fft_dados_de_um_dia[frequencias_dia >= 0.4 & frequencias_dia <= 0.6] <- 
      fft_dados_de_um_dia[frequencias_dia >= 0.4 & frequencias_dia <= 0.6] * 0.5
    
    # Aplicando a Transformada de Fourier Inversa
    dados_de_um_dia_liquid_filtrado <- Re(fft(fft_dados_de_um_dia, inverse = TRUE) / n_dia)



    #diff_ajust_mmgd <- dados_de_um_dia_liquid_filtrado - dados_de_um_dia_liquid
    dados_de_um_dia_mmgd_filtrado_inter <- dados_de_um_dia_mmgd_filtrado

    # Identificando intervalos sem zeros
    rle_non_zeros <- rle(dados_de_um_dia_mmgd != 0)
    non_zero_intervals <- data.frame(
      Start = cumsum(rle_non_zeros$lengths)[rle_non_zeros$values] - rle_non_zeros$lengths[rle_non_zeros$values] + 1,
      End = cumsum(rle_non_zeros$lengths)[rle_non_zeros$values],
      Length = rle_non_zeros$lengths[rle_non_zeros$values]
    )

    # Aplicar ajuste apenas nos intervalos sem zeros, ignorando as três primeiras e três últimas amostras
    for (i in 1:nrow(non_zero_intervals)) {
      start <- non_zero_intervals$Start[i] + 2
      end <- non_zero_intervals$End[i] - 1

      if(metodo == 1){
        if (start <= end) {
          diff_ajust_mmgd <- dados_de_um_dia_liquid_filtrado[start:end] - dados_de_um_dia_liquid[start:end]
          dados_de_um_dia_mmgd_filtrado[start:end] <- dados_de_um_dia_mmgd_filtrado[start:end] + diff_ajust_mmgd
        }
      }
      else{
        if (start <= end) {
          diff_ajust_mmgd <- dados_de_um_dia_liquid_filtrado[start:end] - dados_de_um_dia_liquid[start:end]
          # Aplicar a soma apenas para os pontos positivos
          dados_de_um_dia_mmgd_filtrado[start:end] <- ifelse(
            diff_ajust_mmgd <= 0,
            dados_de_um_dia_mmgd_filtrado[start:end] + diff_ajust_mmgd,
            dados_de_um_dia_mmgd_filtrado[start:end]
          )
        }
      }
    }
    dados_de_um_dia_mmgd_filtrado[dados_de_um_dia_mmgd_filtrado < 0] <- 0
    #--------------------------------------------------------------------------


    if(peakadjustement){
      # Ajustando os picos máximos diários se necessário
      max_original <- max(dados_de_um_dia_mmgd_store)
      max_filtrado <- max(dados_de_um_dia_mmgd_filtrado)

      if (max_original > max_filtrado) {
        fator_ajuste <- max_original / max_filtrado

        # Aplicar o ajuste diferencial aos valores não zerados
        non_zero_indices <- which(dados_de_um_dia_mmgd_filtrado > 0)
        n_non_zero <- length(non_zero_indices)

        if (n_non_zero > 0) {
          quartil_1 <- floor(n_non_zero * 0.10)
          quartil_3 <- floor(n_non_zero * 0.90)

          # Aplicar 0.6 * ajuste para o primeiro e último quartil
          indices_quartil_1 <- non_zero_indices[1:quartil_1]
          indices_quartil_3 <- non_zero_indices[(quartil_3+1):n_non_zero]

          dados_de_um_dia_mmgd_filtrado[indices_quartil_1] <- dados_de_um_dia_mmgd_filtrado[indices_quartil_1] * 0.8 * fator_ajuste
          dados_de_um_dia_mmgd_filtrado[indices_quartil_3] <- dados_de_um_dia_mmgd_filtrado[indices_quartil_3] * 0.8 * fator_ajuste

          # Aplicar ajuste completo para o restante
          indices_restante <- non_zero_indices[(quartil_1+1):quartil_3]
          dados_de_um_dia_mmgd_filtrado[indices_restante] <- dados_de_um_dia_mmgd_filtrado[indices_restante] * fator_ajuste
        }
      }
    }

    # Preparando o vetor de horas para o dia específico
    if(midnight_is_first_hour){
      t_dia <- seq(from = as.POSIXct(paste(year,"-", month, "-", day, " 00:00:00", sep="")), by = "hour", length.out = length(dados_de_um_dia_mmgd))
    } else {
      t_dia <- seq(from = as.POSIXct(paste(year,"-", month, "-", day, " 01:00:00", sep="")), by = "hour", length.out = length(dados_de_um_dia_mmgd))
    }

    return(data.frame(
      time = t_dia,
      Original_microminigersolar = dados_de_um_dia_mmgd_store,
      Filtered_microminigersolar = dados_de_um_dia_mmgd_filtrado_inter,
      Original_liquidofmmgdload = dados_de_um_dia_liquid,
      Filtered_liquidofmmgdload = dados_de_um_dia_liquid_filtrado,
      microminigersolar_Ajusted = dados_de_um_dia_mmgd_filtrado
    ))
  }

  # Aplicando a função para cada dia
  resultado <- data_to_be_treated %>%
    group_by(year_, month_, day_) %>%
    group_modify(~ tratar_dia(.x, .y$year_, .y$month_, .y$day_)) %>%
    ungroup()

  #resultado$Filtered_data <- corrigir_dentes(resultado$Filtered_data)

  return(resultado)
}

#' @export
gera_graficos_muitas_series <- function(data, x, y, series, legend = TRUE) {

  n_groups <- length(unique(series))

  # Criar uma paleta de cores personalizada se o número de grupos for maior que 8
  if (n_groups > 8) {
    custom_colors <- colorRampPalette(brewer.pal(9, "Set1"))(n_groups)
  } else {
    custom_colors <- brewer.pal(n_groups, "Set2")
  }

  fig <- plot_ly(data,
                 x = ~x,
                 y = ~y,
                 color = ~series,
                 colors = custom_colors,
                 type = 'scatter',
                 mode = 'lines',
                 line = list(width = 1.2),
                 legendgroup = ~series,
                 showlegend = legend) %>% config(
                   modeBarButtonsToRemove = list(
                     'lasso2d', 'select2d', 'zoomIn2d', 'zoomOut2d', 'hoverCompareCartesian',
                     'toggleSpikelines', 'hoverClosest3d', 'hoverClosestGeo', 'hoverClosestGl2d',
                     'hoverClosestPie', 'resetViews', 'resetGeo', 'resetViews', 'toggleHover'
                   ),
                   displaylogo = FALSE
                 )

  return(fig)
}
